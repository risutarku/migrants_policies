<script setup lang="ts">
// This component only renders static content, no props yet
</script>
<template>
  <section class="w-full text-center lg:text-left lg:max-w-2xl space-y-6">
    <h1 class="text-4xl lg:text-5xl font-extrabold leading-tight">
      Обязательная медстраховка ДМС <br class="hidden lg:block" />
      <span class="inline-block lg:block">за 5 минут</span>
    </h1>
    <p class="text-lg lg:text-xl leading-relaxed max-w-xl mx-auto lg:mx-0">
      Для миграционного учёта, патента, работы и проживания в Российской Федерации
    </p>
    <p class="text-primary font-bold text-2xl lg:text-3xl tracking-wide">
      ИНГОССТРАХ
    </p>
  </section>
</template>