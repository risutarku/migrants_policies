from __future__ import annotations

from pathlib import Path
from typing import Dict, Any
from datetime import date, datetime

from openpyxl import load_workbook

BASE_DIR = Path(__file__).resolve().parents[3]  # .../backend
TEMPLATE_PATH = BASE_DIR / "templates" / "policy_template.xlsx"
OUT_DIR = BASE_DIR / "generated"
OUT_DIR.mkdir(parents=True, exist_ok=True)


def fmt_date(v: Any) -> str:
    if isinstance(v, (date, datetime)):
        return v.strftime("%d.%m.%Y")
    return str(v) if v is not None else ""


def render_policy_xlsx(values: Dict[str, Any], out_name: str) -> Path:
    if not TEMPLATE_PATH.exists():
        raise FileNotFoundError(f"Template not found: {TEMPLATE_PATH}")

    wb = load_workbook(TEMPLATE_PATH)
    ws = wb.active  # либо wb["ИмяЛиста"]

    # !!! ПОДСТАВЬ РЕАЛЬНЫЕ АДРЕСА ЯЧЕЕК ТВОЕГО ШАБЛОНА !!!
    mapping = {
        "policy_number": "B2",
        "start_date": "B3",
        "end_date": "B4",
        "insurance_days": "B5",
        "issue_date": "B6",
        "insured_full_name": "B7",
        "birthday": "B8",
        "document_number": "B9",
        "premium_total": "B10",     # если нужно печатать цену покупки
        "reward_amount": "B11",     # если нужно печатать вознаграждение
    }

    for key, cell in mapping.items():
        val = values.get(key, "")
        if key in ("start_date", "end_date", "issue_date", "birthday"):
            val = fmt_date(val)
        ws[cell].value = val

    out_path = OUT_DIR / f"{out_name}.xlsx"
    wb.save(out_path)
    return out_path
