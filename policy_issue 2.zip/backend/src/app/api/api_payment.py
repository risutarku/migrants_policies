from fastapi import APIRouter, HTTPException, Depends
import httpx
from uuid import UUID
import asyncio, time, random
from sqlalchemy.orm import Session

from app.models.payment import PayInitReq, PayInitResp, PayStatusResp, PayCallback
from app.services.payment_service import pay_store
from app.services.policy_db_service import create_policy_draft, mark_policy_paid
from app.models.to_csv import RegisterUser
from app.db import get_db

router = APIRouter()

from pydantic import BaseModel
from typing import Any, Optional

class DraftSaveReq(BaseModel):
    employee_tab_number: str
    arrived_for_hire: bool
    lang: Optional[str] = None
    policy_variant: Optional[str] = None
    user: dict[str, Any]
    contacts: dict[str, Any]
    policy: dict[str, Any]


class PayInitReqWithPolicyId(PayInitReq):
    """Расширенный запрос с policy_id вместо random UUID"""
    policy_id: int


@router.post("/draft-save", status_code=201)
async def save_policy_draft(p: DraftSaveReq, db: Session = Depends(get_db)):
    draft = RegisterUser(user=p.user, contacts=p.contacts, policy=p.policy)
    policy_id = await create_policy_draft(
        draft=draft,
        employee_tab_number=p.employee_tab_number,
        arrived_for_hire=p.arrived_for_hire,
        db=db,
    )
    return {"policy_id": policy_id}



@router.post("/init", response_model=PayInitResp, status_code=201)
async def payment_init(req: PayInitReqWithPolicyId):
    """
    Инициирует оплату для существующего полиса.
    """
    sid = pay_store.create(req.session_id, req.idempotency_key, req.policy.amount)
    # Сохраняем policy_id в памяти (можно также в pay_store)
    pay_store.store[str(sid)]['policy_id'] = req.policy_id
    if pay_store.get(sid)['status'] == "pending":
        asyncio.create_task(_mock_terminal(sid))
    return PayInitResp(session_id=sid, amount=req.policy.amount)


async def _mock_terminal(sid: UUID):
    await asyncio.sleep(2)
    tx_id = f"TX-{int(time.time())}-{random.randint(100,999)}"
    async with httpx.AsyncClient() as c:
        await c.post(
            "http://localhost:8000/payment/callback",
            json={"session_id": str(sid), "tx_id": tx_id, "status": "success"},
            timeout=5,
        )


@router.get("/status/{sid}", response_model=PayStatusResp)
async def payment_status(sid: UUID):
    rec = pay_store.get(sid)
    if not rec:
        raise HTTPException(404, "session not found")
    return PayStatusResp(session_id=sid, **{k: v for k, v in rec.items() if k in ["status", "tx_id"]})


@router.post("/callback", status_code=204)
async def payment_callback(cb: PayCallback, db: Session = Depends(get_db)):
    """
    Callback после успешной оплаты.
    Обновляет статус полиса в БД.
    """
    rec = pay_store.get(cb.session_id)
    if not rec:
        raise HTTPException(404, "session unknown")
    pay_store.mark(cb.session_id, cb.status, cb.tx_id)
    
    if cb.status == "success":
        policy_id = rec.get('policy_id')
        if policy_id:
            await mark_policy_paid(policy_id, cb.tx_id, db)
    return None